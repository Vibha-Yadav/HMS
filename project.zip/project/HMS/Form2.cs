﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System {
    public partial class Form2 : Form {
        string username;
        public Form2(string user) {
            InitializeComponent();
            username = user;
        }

        private void button1_Click(object sender, EventArgs e) {
           
        }

        private void button2_Click(object sender, EventArgs e) {
            panel2.Controls.Clear();
            Pharmacy pharm = new Pharmacy(panel2);
            pharm.TopLevel = false;
            pharm.AutoScroll = true;
            panel2.Controls.Add(pharm);
            pharm.Show();
        }

        private void button6_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e) {
           // label2.Text = "Welcome " + username;
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Form5 appoint = new Form5(panel2);
            appoint.TopLevel = false;
            appoint.AutoScroll = true;
            panel2.Controls.Add(appoint);
            appoint.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel2.BackgroundImage = null;
            panel2.Controls.Clear();
            ViewRooms viewRooms = new ViewRooms();
            viewRooms.TopLevel = false;
            viewRooms.AutoScroll = true;
            panel2.Controls.Add(viewRooms);
            viewRooms.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }
    }
}
