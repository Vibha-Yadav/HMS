﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System {
    public partial class UpdateRecord : Form {
        public Panel panel1;
        public UpdateRecord(Panel panel) {
            InitializeComponent();
            panel1 = panel;
        }

        

        private void dOCTORToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UpdatePhysician updatePhysician = new UpdatePhysician();
            updatePhysician.TopLevel = false;
            updatePhysician.AutoScroll = true;
            panel1.Controls.Add(updatePhysician);
            updatePhysician.Show();
        }

        private void nURSEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UpdateNurse updateNurse = new UpdateNurse();
            updateNurse.TopLevel = false;
            updateNurse.AutoScroll = true;
            panel1.Controls.Add(updateNurse);
            updateNurse.Show();
        }

        private void sTAFFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            UpdateStaff updateStaff = new UpdateStaff();
            updateStaff.TopLevel = false;
            updateStaff.AutoScroll = true;
            panel1.Controls.Add(updateStaff);
            updateStaff.Show();
        }

        private void UpdateRecord_Load(object sender, EventArgs e)
        {

        }
    }
}
