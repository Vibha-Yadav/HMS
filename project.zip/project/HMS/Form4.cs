﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class Form4 : Form
    {
        public Panel panel1;
        public Form4(Panel panel)
        {
            InitializeComponent();
            panel1 = panel;
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void nURSESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewNurses viewNurses = new ViewNurses();
            viewNurses.TopLevel = false;
            viewNurses.AutoScroll = true;
            panel1.Controls.Add(viewNurses);
            viewNurses.Show();
        }

        private void pATIENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewPatients viewPatients = new ViewPatients();
            viewPatients.TopLevel = false;
            viewPatients.AutoScroll = true;
            panel1.Controls.Add(viewPatients);
            viewPatients.Show();
        }

        private void pYHSICIANSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewPhysicians viewPhysicians = new ViewPhysicians();
            viewPhysicians.TopLevel = false;
            viewPhysicians.AutoScroll = true;
            panel1.Controls.Add(viewPhysicians);
            viewPhysicians.Show();
        }

        private void uSERSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewUsers viewUsers = new ViewUsers();
            viewUsers.TopLevel = false;
            viewUsers.AutoScroll = true;
            panel1.Controls.Add(viewUsers);
            viewUsers.Show();
        }

        private void rOOMSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewRooms viewRooms = new ViewRooms();
            viewRooms.TopLevel = false;
            viewRooms.AutoScroll = true;
            panel1.Controls.Add(viewRooms);
            viewRooms.Show();
        }

        private void aPPOINTMENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BackgroundImage = null;
            panel1.Controls.Clear();
            ViewAppointmentsAdmin viewAppointmentsAdmin = new ViewAppointmentsAdmin();
            viewAppointmentsAdmin.TopLevel = false;
            viewAppointmentsAdmin.AutoScroll = true;
            panel1.Controls.Add(viewAppointmentsAdmin);
            viewAppointmentsAdmin.Show();
        }
    }
}
