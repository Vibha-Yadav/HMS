﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System {
    public partial class Form3 : Form {

        private string patientName;
        public Form3(string Name) {
            InitializeComponent();
            patientName = Name;
        }

        private void Form3_Load(object sender, EventArgs e) {
            dateTimePicker1.MinDate = DateTime.Today;
            textBox1.Text =patientName;
            textBox1.ReadOnly = true;
        }
    }
}
