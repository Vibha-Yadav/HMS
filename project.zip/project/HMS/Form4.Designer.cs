﻿namespace Hospital_Management_System
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.nURSESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pATIENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pYHSICIANSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uSERSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rOOMSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aPPOINTMENTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nURSESToolStripMenuItem,
            this.pATIENTSToolStripMenuItem,
            this.pYHSICIANSToolStripMenuItem,
            this.uSERSToolStripMenuItem,
            this.rOOMSToolStripMenuItem,
            this.aPPOINTMENTSToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // nURSESToolStripMenuItem
            // 
            this.nURSESToolStripMenuItem.Name = "nURSESToolStripMenuItem";
            this.nURSESToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.nURSESToolStripMenuItem.Text = "NURSES";
            this.nURSESToolStripMenuItem.Click += new System.EventHandler(this.nURSESToolStripMenuItem_Click);
            // 
            // pATIENTSToolStripMenuItem
            // 
            this.pATIENTSToolStripMenuItem.Name = "pATIENTSToolStripMenuItem";
            this.pATIENTSToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.pATIENTSToolStripMenuItem.Text = "PATIENTS";
            this.pATIENTSToolStripMenuItem.Click += new System.EventHandler(this.pATIENTSToolStripMenuItem_Click);
            // 
            // pYHSICIANSToolStripMenuItem
            // 
            this.pYHSICIANSToolStripMenuItem.Name = "pYHSICIANSToolStripMenuItem";
            this.pYHSICIANSToolStripMenuItem.Size = new System.Drawing.Size(85, 20);
            this.pYHSICIANSToolStripMenuItem.Text = "PYHSICIANS";
            this.pYHSICIANSToolStripMenuItem.Click += new System.EventHandler(this.pYHSICIANSToolStripMenuItem_Click);
            // 
            // uSERSToolStripMenuItem
            // 
            this.uSERSToolStripMenuItem.Name = "uSERSToolStripMenuItem";
            this.uSERSToolStripMenuItem.Size = new System.Drawing.Size(52, 20);
            this.uSERSToolStripMenuItem.Text = "USERS";
            this.uSERSToolStripMenuItem.Click += new System.EventHandler(this.uSERSToolStripMenuItem_Click);
            // 
            // rOOMSToolStripMenuItem
            // 
            this.rOOMSToolStripMenuItem.Name = "rOOMSToolStripMenuItem";
            this.rOOMSToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.rOOMSToolStripMenuItem.Text = "ROOMS";
            this.rOOMSToolStripMenuItem.Click += new System.EventHandler(this.rOOMSToolStripMenuItem_Click);
            // 
            // aPPOINTMENTSToolStripMenuItem
            // 
            this.aPPOINTMENTSToolStripMenuItem.Name = "aPPOINTMENTSToolStripMenuItem";
            this.aPPOINTMENTSToolStripMenuItem.Size = new System.Drawing.Size(106, 20);
            this.aPPOINTMENTSToolStripMenuItem.Text = "APPOINTMENTS";
            this.aPPOINTMENTSToolStripMenuItem.Click += new System.EventHandler(this.aPPOINTMENTSToolStripMenuItem_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem nURSESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pATIENTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pYHSICIANSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uSERSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rOOMSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aPPOINTMENTSToolStripMenuItem;
    }
}