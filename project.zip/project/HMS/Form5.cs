﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hospital_Management_System
{
    public partial class Form5 : Form
    {
        public Panel panel2;
        public Form5(Panel panel)
        {
            InitializeComponent();
            panel2 = panel;
        }

        private void vIEWAPPOINTMENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            ViewAppointment viewAppointment = new ViewAppointment();
            viewAppointment.TopLevel = false;
            viewAppointment.AutoScroll = true;
            panel2.Controls.Add(viewAppointment);
            viewAppointment.Show();
        }

        private void bOOKAPPOINTMENTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel2.Controls.Clear();
            Appointment bookAppointment = new Appointment(panel2);
            bookAppointment.TopLevel = false;
            bookAppointment.AutoScroll = true;
            panel2.Controls.Add(bookAppointment);
            bookAppointment.Show();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }
    }
}
