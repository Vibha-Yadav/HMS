﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Data.SqlClient;


namespace Hospital_Management_System
{
    public partial class Pharmacy : Form
    {
        public Panel panel2;
        ConnectionDB conn = new ConnectionDB();
        private static ArrayList Listcode = new ArrayList();
        private static ArrayList Listname = new ArrayList();
        public Pharmacy(Panel panel)
        {
            InitializeComponent();
        }

        private void Pharmacy_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            Listcode.Clear();
            Listname.Clear();
            GetData();
            if (Listcode.Count > 0)
            {
                updateDatagrid();
            }
        }
        private void GetData()
        {
            try
            {
                conn.Open();
                string query = "select * from medication";
                SqlDataReader row;
                row = conn.ExecuteReader(query);
                if (row.HasRows)
                {
                    while (row.Read())
                    {
                        Listcode.Add(row["code"].ToString());
                        Listname.Add(row["name"].ToString());
                        
                    }
                }
                else
                {
                    MessageBox.Show("Data not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                conn.Close();
            }
            catch (Exception err)
            {
                MessageBox.Show(err.ToString());
            }

        }
        private void updateDatagrid()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < Listcode.Count; i++)
            {
                DataGridViewRow newRow = new DataGridViewRow();
                newRow.CreateCells(dataGridView1);
                newRow.Cells[0].Value = Listcode[i];
                newRow.Cells[1].Value = Listname[i];                
                dataGridView1.Rows.Add(newRow);
            }
        }
    }
}
