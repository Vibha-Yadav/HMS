﻿namespace Hospital_Management_System {
    partial class AddRecord {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.nURSEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pHYSICIANToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTAFFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nURSEToolStripMenuItem,
            this.pHYSICIANToolStripMenuItem,
            this.sTAFFToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1045, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // nURSEToolStripMenuItem
            // 
            this.nURSEToolStripMenuItem.Name = "nURSEToolStripMenuItem";
            this.nURSEToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.nURSEToolStripMenuItem.Text = "NURSE";
            // 
            // pHYSICIANToolStripMenuItem
            // 
            this.pHYSICIANToolStripMenuItem.Name = "pHYSICIANToolStripMenuItem";
            this.pHYSICIANToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.pHYSICIANToolStripMenuItem.Text = "PHYSICIAN";
            this.pHYSICIANToolStripMenuItem.Click += new System.EventHandler(this.pHYSICIANToolStripMenuItem_Click);
            // 
            // sTAFFToolStripMenuItem
            // 
            this.sTAFFToolStripMenuItem.Name = "sTAFFToolStripMenuItem";
            this.sTAFFToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.sTAFFToolStripMenuItem.Text = "STAFF";
            this.sTAFFToolStripMenuItem.Click += new System.EventHandler(this.sTAFFToolStripMenuItem_Click);
            // 
            // AddRecord
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1045, 491);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AddRecord";
            this.Text = "AddRecord";
            this.Load += new System.EventHandler(this.AddRecord_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem nURSEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pHYSICIANToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTAFFToolStripMenuItem;
    }
}